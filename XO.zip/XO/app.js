//creating i to keep the order of players
let i = 0;

//creating winBool to stop the game whenever someone wins
let winBool = true;

//creating p[1-9] not to let fill the same blank twice
let p1 = p2 = p3 = p4 = p5 = p6 = p7 = p8 = p9 = true;

//creating an array to hold x and o inside
let arr =
[
    [0,0,0],
    [0,0,0],
    [0,0,0]
];


//checking if someone won
function winCheck(arr)
{
    for(let i = 0; i < arr.length;i++)
    {
        //horizontal line check
        if(arr[i][0] == arr[i][1] && arr[i][1] == arr[i][2] && arr[i][0] == arr[i][2])
        {
            //in case x wins
            if(arr[i][0] == 1)
            {
                document.getElementById("playerTurn").innerHTML = "X Won";
                winBool = false;
            }

            //in case o wins
            if(arr[i][0] == 2)
            {
                document.getElementById("playerTurn").innerHTML = "O Won";
                winBool = false;
            }
        }

        //vertical line check
        if(arr[0][i] == arr[1][i] && arr[1][i] == arr[2][i] && arr[0][i] == arr[2][i])
        {
            //in case x wins
            if(arr[0][i] == 1)
            {
                document.getElementById("playerTurn").innerHTML = "X Won";
                winBool = false;
            }

            //in case o wins
            if(arr[0][i] == 2)
            {
                document.getElementById("playerTurn").innerHTML = "O Won";
                winBool = false;
            }
        }
    }

    //checking dioganal1
    if(arr[0][0] == arr[1][1] && arr[1][1] == arr[2][2] && arr[0][0] == arr[2][2])
    {
        if(arr[0][0] == 1)
        {
            document.getElementById("playerTurn").innerHTML = "X Won";
            winBool = false;
        }
        if(arr[0][0] == 2)
        {
            document.getElementById("playerTurn").innerHTML = "O Won";
            winBool = false;
        }
    }

    //checking dioganal2
    if(arr[0][2] == arr[1][1] && arr[1][1] == arr[2][0] && arr[0][2] == arr[2][0])
    {
        if(arr[0][2] == 1)
        {
            document.getElementById("playerTurn").innerHTML = "X Won";
            winBool = false;
        }
        if(arr[0][2] == 2)
        {
            document.getElementById("playerTurn").innerHTML = "O Won";
            winBool = false;
        }
    }
}

//keeping the order
function turn(i)
{
    if(i % 2 == 0)
        {
            document.getElementById("playerTurn").innerHTML = "X Turn";
        }
        else
        {
            document.getElementById("playerTurn").innerHTML = "O Turn";
        }   
}

turn(i);

const element1 = document.getElementById("box1_1");
element1.addEventListener("click", foo1);
function foo1() {
    //if no-one won and the blank is empty fill the blank when its clicked
    if(winBool)
    {
        if(p1)
        {
            if(i % 2 == 0)
            {
                document.getElementById("box1_1_p").innerHTML = "X";
                arr[0][0] = 1;
            }
            else
            {
                document.getElementById("box1_1_p").innerHTML = "O";
                arr[0][0] = 2;
            }
            p1 = false;
            i+=1;
            turn(i);
            winCheck(arr);
        }
    }
}


const element2 = document.getElementById("box1_2");
element2.addEventListener("click", foo2);
function foo2() {
    if(winBool)
    {
        if(p2)
        {
            if(i % 2 == 0)
            {
                document.getElementById("box1_2_p").innerHTML = "X";
                arr[1][0] = 1;
            }
            else
            {
                document.getElementById("box1_2_p").innerHTML = "O";
                arr[1][0] = 2;
            }
            p2 = false;
            i+=1;
            turn(i);
            winCheck(arr);
        }
        
    }

}


const element3 = document.getElementById("box1_3");
element3.addEventListener("click", foo3);
function foo3() {
    if(winBool)
    {
        if(p3)
        {
            if(i % 2 == 0)
            {
                document.getElementById("box1_3_p").innerHTML = "X";
                arr[2][0] = 1;
            }
            else
            {
                document.getElementById("box1_3_p").innerHTML = "O";
                arr[2][0] = 2;
            }
            p3 = false;
            i+=1;
            turn(i);
            winCheck(arr);
        }

    }
}

const element4 = document.getElementById("box2_1");
element4.addEventListener("click", foo4);
function foo4() {
    if(winBool)
    {
        if(p4)
        {
            if(i % 2 == 0)
            {
                document.getElementById("box2_1_p").innerHTML = "X";
                arr[0][1] = 1;
            }
            else
            {
                document.getElementById("box2_1_p").innerHTML = "O";
                arr[0][1] = 2;
            }
            p4 = false;
            i+=1;
            turn(i);
            winCheck(arr);
        }

    }
    
}

const element5 = document.getElementById("box2_2");
element5.addEventListener("click", foo5);
function foo5() {
    if(p5)
    {
        if(winBool)
        {
            if(i % 2 == 0)
            {
                document.getElementById("box2_2_p").innerHTML = "X";
                arr[1][1] = 1;
            }
            else
            {
                document.getElementById("box2_2_p").innerHTML = "O";
                arr[1][1] = 2;
            }
            p5 = false;
            i+=1;
            turn(i);
            winCheck(arr);
        }
    }

    
}

const element6 = document.getElementById("box2_3");
element6.addEventListener("click", foo6);
function foo6() {
    if(winBool)
    {
        if(p6)
        {
            if(i % 2 == 0)
            {
                document.getElementById("box2_3_p").innerHTML = "X";
                arr[2][1] = 1;
            }
            else
            {
                document.getElementById("box2_3_p").innerHTML = "O";
                arr[2][1] = 2;
            }
            p6 = false;
            i+=1;
            turn(i);
            winCheck(arr);
        }

    }
}

const element7 = document.getElementById("box3_1");
element7.addEventListener("click", foo7);
function foo7() {
    if(winBool)
    {
        if(p7)
        {
            if(i % 2 == 0)
            {
                document.getElementById("box3_1_p").innerHTML = "X";
                arr[0][2] = 1;
            }
            else
            {
                document.getElementById("box3_1_p").innerHTML = "O";
                arr[0][2] = 2;
            }
            p7 = false;
            i+=1;
            turn(i);
            winCheck(arr);
        }
        
    }
    
}

const element8 = document.getElementById("box3_2");
element8.addEventListener("click", foo8);
function foo8() {
    if(winBool)
    {
        if(p8)
        {
            if(i % 2 == 0)
            {
                document.getElementById("box3_2_p").innerHTML = "X";
                arr[1][2] = 1;
            }
            else
            {
                document.getElementById("box3_2_p").innerHTML = "O";
                arr[1][2] = 2;
            }
            p8 = false;
            i+=1;
            turn(i);
            winCheck(arr);
        }
        
    } 
}

const element9 = document.getElementById("box3_3");
element9.addEventListener("click", foo9);
function foo9() {
    if(winBool)
    {
        if(p9)
        {
            if(i % 2 == 0)
            {
                document.getElementById("box3_3_p").innerHTML = "X";
                arr[2][2] = 1;
            }
            else
            {
                document.getElementById("box3_3_p").innerHTML = "O";
                arr[2][2] = 2;
            }
            p9 = false;
            i+=1;
            turn(i);
            winCheck(arr);
        }
        
    }
}